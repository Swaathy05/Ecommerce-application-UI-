package com.example.myapplication.ui

class FlashUiState(
    val clickStatus:String="View Models",
    val selectedCategory:String=""
) {
}